@echo off
setlocal
cd /d "%~dp0"
java -cp RiyadhPoly.jar RentTest
set "result=%ERRORLEVEL%"
pause
exit /b %result%
