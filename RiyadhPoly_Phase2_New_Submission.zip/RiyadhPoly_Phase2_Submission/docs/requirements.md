# Phase 2 requirement audit

Sources: the uploaded “Phase 2 — Players and Money 2” and the Overview supplied in
this conversation. “Met” below means implemented and checked in the prepared
Java 21 environment. It does not assert a mark or certify student understanding.

| Requirement | Verdict | Location and verification |
| --- | --- | --- |
| Extend the newly uploaded Phase 1 project using Java | Met | Existing Board implementation and square data retained; src/ additions |
| Abstract Player | Met | Player.java |
| Name, cash, position, owned list, turnsInJail | Met | Player state; cash held exactly in cents; initial GO/$800 |
| Abstract boolean wantsToBuy(Ownable) | Met | Player declaration, two bot overrides |
| Comparable<Player> | Met | Player.compareTo; worth/cash/name tie-break tests |
| CautiousBot/AggressiveBot own buying policies | Met | Tests at and below affordability/reserve boundaries |
| One seeded Random; two six-sided dice | Met | Dice; 1,000 independent paired-roll checks |
| Game contains board, players and dice | Met | Game fields |
| Game startup, single turn, loop and leaderboard | Met | startup, takeTurn, play, printLeaderboard |
| Square abstract with seven subclasses | Met | Retained hierarchy; destination dispatch tested |
| Ownable interface implemented by properties/stations | Met | Both land methods call resolveOwnable |
| ArrayList board, players, ownership | Met | Board, Game, Player; protected collection copies |
| Map<String, ArrayList<Ownable>> groups | Met | Existing Board.ownershipGroups |
| Board-file I/O and InvalidBoardException | Met | Existing loader; all three invalid fixtures rejected |
| Safe Scanner input | Met | Whole-line validation, overflow/type/name/EOF tests |
| Required static final constants | Met | NUM_PLAYERS, INITIAL_CASH, SALARY, MAX_ROUNDS, BUYOUT_FACTOR in Game; BOT_RESERVE in CautiousBot |
| 4 players by default, creation-order turns | Met | Independent audit checks every turn |
| All players start at GO with $800 | Met | Player initialization |
| Forward movement by sum modulo 20 | Met | movePlayer, independent seed/movement audit |
| Print both dice and sum | Met | takeTurn output independently verified |
| $100 salary on passing or landing exactly on GO | Met | Boundary tests and full-output audit |
| Destination decides effect through land(player, game) | Met | takeTurn calls Square.land |
| 20 rounds, every player every round | Met | Complete game tests including negative cash |
| Cautious ordinary purchase leaves at least $300 | Met | Boundary checks; earlier-group purchase does not bypass reserve |
| Aggressive buys whenever price affordable | Met | Exact-funds and insufficient-funds checks |
| Unowned: normal buying rule | Met | offerBankPurchase |
| Own square: no payment | Met | resolveOwnable own-owner branch |
| Opponent: rent unless buy-out applies | Met | settleVisit; cash transfer tests |
| Rent from board, doubled for complete group | Met | Property and large-rent tests; independent audit |
| Stations in RAILROAD: $100/$200 rent | Met | Both station cases tested |
| Buy-out needs ownership of every OTHER group square | Met | finishesGroup uses countOwned == groupSize - 1 |
| Buy-out only on opponent-owned landing | Met | Owner branch precedes settleVisit; wealth alone cannot buy out |
| Exact 1.5x price, sufficient cash, seller paid instead of rent | Met | Whole and fractional property/station tests |
| Unaffordable buy-out: pay rent | Met | $179/$180 and $181/$181.50 boundaries |
| Last unowned member: normal price; every bot buys if affordable | Met | Both bots tested for properties and stations |
| Cautious reserve waived for completion and buy-out | Met | Both bots tested with exact funds |
| One method updates owner and both lists for all purchases/buy-outs | Met | transferOwnership is sole gameplay setOwner call |
| Net worth = cash + original asset prices | Met | getNetWorthCents; independent complete-game audit |
| Every round displays name, cash, net worth | Met | printLeaderboard; all 20 standings audited |
| Collections.sort uses compareTo; worth/cash descending, names ascending | Met | Sorting tests; copy protects turn order |
| GO/Park/Jail visiting messages | Met | No unintended money or jail effects |
| Chance/Go To Jail permitted placeholders | Met | Printed Phase 3 notices |
| Separate RentTest.main | Met | $180 buy-out, $96 rent, Rana $516 / Yousef $764, both lists checked |
| Same seed and inputs give exactly same output | Met | Byte-for-byte packaged-game comparison |
| Changing only NUM_PLAYERS to 2 works | Met | Temporary source copy; full 20-round/40-turn audit |
| Letter seed/unknown bot type do not crash | Met | Console recovery tests |
| Overview-style actions and money | Met | Equivalent messages; required amounts retained; example names changed |
| Code uses parent types for behavior | Met | Gameplay uses Player, Square, Ownable; concrete construction limited to setup/loader |
| Current class diagram | Met | phase2.drawio plus readable SVG exports |

## Evidence and external requirements

- `verification.txt`: 70 rule checks and RentTest results.
- `console_audit.txt`: six audit groups, including 128 games / 10,240 turns on
  standard and odd-priced boards, all 16 bot-type combinations.
- `seed42_game.txt`: full reproducible example with Samira/A, Nabil/C, Dalia/C,
  Omar/A. Seed alone is not sufficient if player strategies or board differ.
- Separate LMS `RiyadhPoly_sample_output.txt`: not provided; direct comparison
  against that file is **unverified**. No substitute is represented as that file.
- AI-use log: **not included**, following the user's earlier preference. The
  Overview's final-submission log requirement is therefore **unmet**.
- Group of three, timely LMS submission, next-lab check-in and each member's own
  explanation: **student obligations, not verifiable through this code**.
- ChanceCard/deck, jail penalties, Iterator-based bankruptcy and final winner:
  **not due in Phase 2**, explicitly assigned to Phase 3.

No code defect or missing Phase 2 gameplay feature remains in these checks.
Testing does not establish every possible future modification or grading outcome.
