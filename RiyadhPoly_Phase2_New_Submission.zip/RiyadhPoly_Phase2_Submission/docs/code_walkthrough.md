# Explain your Phase 2 program

The instructor may ask any member to explain any class. Read the actual source
and practice changes; this document is preparation, not proof of understanding.

1. **Where is ownership changed?** `Game.transferOwnership`. Seller null means
   bank. It debits the buyer, credits/removes from a seller when present, adds to
   the buyer's list, then sets the owner. Bank purchases and buy-outs both call it.
   Its payment argument is in CENTS: 18000 means $180.
2. **Where does a buy-out happen?** `settleVisit`, reached only for another player's
   asset. `finishesGroup` checks countOwned == groupSize - 1; cash must cover the
   entire 1.5x price. The successful branch returns before rent is charged.
3. **Why is Player abstract?** It shares state and accounting but does not choose a
   universal policy. Each bot overrides wantsToBuy. Game deals with Player rather
   than testing concrete bot types during a turn.
4. **Why does cautious sometimes spend below $300?** The reserve governs ordinary
   purchases. Affordable completion is a shared game rule that bypasses it. Rent
   can also push balances below $300 or below zero.
5. **Why does Dice retain one Random?** The next random pair must continue the same
   seeded sequence. Recreating Random inside roll would break that behavior.
6. **Why long cents?** A $121 board price has a $181.50 buy-out. 18150 cents is exact.
   Amounts converts at the API/display boundary; balances and sorting never drop
   fractions. Net worth adds ORIGINAL board prices, not buy-out premiums.
7. **Why Collections.sort on a copy?** Standings order is different from turn order.
   Sorting players itself would change who acts first next round. compareTo uses
   net worth descending, cash descending, then names ascending.
8. **How is salary handled?** movePlayer wraps modulo 20. A smaller new position
   means forward movement crossed or landed on GO, so pay $100 once. GoSquare
   itself only prints a message to avoid a second payment on an exact landing.
9. **Which rules are deferred?** Chance cards, jail penalties, bankruptcy removal
   and winner selection are Phase 3. Phase 2 leaves all players in its round loop.
10. **RentTest arithmetic:** Rana starts $800, buys two browns for $200, then pays
    $180 for the last brown: $420. Yousef starts $800, spends $120, receives $180:
    $860. Al-Bathaa base rent is $48; full brown group doubles it to $96. After that
    payment Rana has $516 and Yousef $764. Both owner lists must agree.

Practice: change SALARY or BOT_RESERVE, rebuild, run the tests and explain which
expectations changed. For the required player-count demonstration, change only
Game.NUM_PLAYERS to 2, rebuild, then enter two players and verify 40 total turns.
