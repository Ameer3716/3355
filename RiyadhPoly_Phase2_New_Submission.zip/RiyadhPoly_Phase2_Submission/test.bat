@echo off
setlocal
cd /d "%~dp0"
call build.bat
if errorlevel 1 exit /b 1
if not exist out-tests mkdir out-tests
where javac >nul 2>nul
if errorlevel 1 (
    java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp out -d out-tests tests\*.java
) else (
    javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp out -d out-tests tests\*.java
)
if errorlevel 1 exit /b 1
java -cp "out;out-tests" Phase2Checks
if errorlevel 1 exit /b 1
java -cp out RentTest
set "result=%ERRORLEVEL%"
pause
exit /b %result%
