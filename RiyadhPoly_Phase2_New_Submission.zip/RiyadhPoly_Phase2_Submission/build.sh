#!/usr/bin/env sh
set -eu
cd -- "$(dirname -- "$0")"
mkdir -p out
if command -v javac >/dev/null 2>&1; then
    javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -d out src/*.java
else
    java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 8 -target 8 -Xlint:-options -d out src/*.java
fi
if command -v jar >/dev/null 2>&1; then
    jar cfe RiyadhPoly.jar RiyadhPolyApp -C out .
else
    java -m jdk.jartool/sun.tools.jar.Main cfe RiyadhPoly.jar RiyadhPolyApp -C out .
fi
printf '%s\n' 'Application prepared: RiyadhPoly.jar'
