@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
where javac >nul 2>nul
if errorlevel 1 (
    java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 8 -target 8 -Xlint:-options -d out src\*.java
) else (
    javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -d out src\*.java
)
if errorlevel 1 exit /b 1
where jar >nul 2>nul
if errorlevel 1 (
    java -m jdk.jartool/sun.tools.jar.Main cfe RiyadhPoly.jar RiyadhPolyApp -C out .
) else (
    jar cfe RiyadhPoly.jar RiyadhPolyApp -C out .
)
if errorlevel 1 exit /b 1
echo Application prepared: RiyadhPoly.jar
