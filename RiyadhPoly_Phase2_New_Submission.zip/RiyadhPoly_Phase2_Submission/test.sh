#!/usr/bin/env sh
set -eu
cd -- "$(dirname -- "$0")"
sh build.sh
mkdir -p out-tests
if command -v javac >/dev/null 2>&1; then
    javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp out -d out-tests tests/*.java
else
    java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp out -d out-tests tests/*.java
fi
java -cp 'out:out-tests' Phase2Checks
java -cp out RentTest
