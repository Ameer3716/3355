@echo off
setlocal
cd /d "%~dp0"
java -jar RiyadhPoly.jar %*
set "result=%ERRORLEVEL%"
pause
exit /b %result%
