import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/** Checks the rules with prepared situations, independently of random landing luck. */
public class Phase2Checks {
    private static int checks;

    private static void verify(String label, boolean correct) {
        if (!correct) { throw new AssertionError(label); }
        checks++;
        System.out.println("OK: " + label);
    }

    private static Game session() throws Exception { return new Game("board.txt", 42); }

    private static Player balance(Player player, double dollars) {
        player.adjustCash(dollars - player.getCash());
        return player;
    }

    private static void give(Game game, int index, Player owner) {
        game.transferOwnership(game.getBoard().getOwnable(index), null, owner, 0);
    }

    private static String record(Runnable action) throws Exception {
        PrintStream previous = System.out;
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (PrintStream capture = new PrintStream(bytes, true, "UTF-8")) {
            System.setOut(capture);
            action.run();
        } finally { System.setOut(previous); }
        return bytes.toString("UTF-8");
    }

    private static int times(String output, String fragment) {
        return (output.length() - output.replace(fragment, "").length()) / fragment.length();
    }

    private static String setup(String seed) {
        StringBuilder input = new StringBuilder(seed).append('\n');
        for (int seat = 1; seat <= Game.NUM_PLAYERS; seat++) {
            input.append("Seat").append(seat).append('\n').append(seat % 2 == 0 ? "C\n" : "A\n");
        }
        return input.toString();
    }

    private static void start(Game game, String input) {
        if (!game.startup(new Scanner(input))) { throw new AssertionError("Unexpected cancellation"); }
    }

    public static void main(String[] args) throws Exception {
        boardChecks();
        buyingChecks();
        rentAndBuyoutChecks();
        movementAndRankingChecks();
        inputAndRoundChecks();
        customMoneyChecks();
        System.out.println("SUCCESS: " + checks + " checks completed.");
    }

    private static void boardChecks() throws Exception {
        Board board = new Board("board.txt");
        verify("20 ordered locations", board.getSquares().size() == 20
                && board.getSquare(0).getIndex() == 0 && board.getSquare(19).getIndex() == 19);
        verify("four property groups and one station group", board.getGroupSize(ColorGroup.BROWN) == 3
                && board.getGroupSize(ColorGroup.YELLOW) == 3 && board.getGroupSize(ColorGroup.GREEN) == 3
                && board.getGroupSize(ColorGroup.BLUE) == 3 && board.getGroupSize(ColorGroup.RAILROAD) == 2);
        int properties = 0, stations = 0, specials = 0;
        for (Square square : board.getSquares()) {
            if (square instanceof PropertySquare) { properties++; }
            else if (square instanceof StationSquare) { stations++; }
            else { specials++; }
        }
        verify("12 properties, 2 stations, 6 special squares", properties == 12 && stations == 2 && specials == 6);
        verify("board data supplies name, price and rent", board.getOwnable(2).getName().equals("Al-Bathaa")
                && board.getOwnable(2).getPrice() == 100 && board.getOwnable(2).getBaseRent() == 48);
        board.getSquares().clear();
        verify("board collection is protected", board.getSquares().size() == 20);
        verify("unowned assets do not count as null player ownership", board.countOwned(null, ColorGroup.BROWN) == 0);
        for (String file : new String[] {"invalid_missing_field.txt", "invalid_unknown_group.txt", "invalid_non_numeric_price.txt"}) {
            try {
                new Board("invalid_board_exceptions/" + file);
                throw new AssertionError("Malformed board accepted: " + file);
            } catch (InvalidBoardException expected) {
                verify("reject malformed board " + file, expected.getMessage().contains("line "));
            }
        }
        try {
            board.getOwnable(0);
            throw new AssertionError("Special square returned as ownable");
        } catch (IllegalArgumentException expected) { verify("GO cannot be owned", true); }
    }

    private static void buyingChecks() throws Exception {
        Game game = session();
        Ownable first = game.getBoard().getOwnable(1);
        Player careful = balance(new CautiousBot("Careful"), 399);
        verify("cautious refuses below reserve", !careful.wantsToBuy(first));
        careful.adjustCash(1);
        verify("cautious accepts exactly $300 remaining", careful.wantsToBuy(first));
        Player bold = balance(new AggressiveBot("Bold"), 99);
        verify("aggressive refuses insufficient funds", !bold.wantsToBuy(first));
        bold.adjustCash(1);
        verify("aggressive accepts exact funds", bold.wantsToBuy(first));
        game.getBoard().getSquare(1).land(bold, game);
        verify("purchase updates cash, owner, list and net worth", bold.getCash() == 0
                && first.getOwner() == bold && bold.getProperties().size() == 1 && bold.getNetWorth() == 100);
        game.resolveOwnable(bold, first);
        verify("own square costs nothing and creates no duplicate", bold.getCash() == 0 && bold.getProperties().size() == 1);
        bold.getProperties().clear();
        verify("owned list getter protects state", bold.getProperties().size() == 1);
        for (boolean cautious : new boolean[] {true, false}) {
            Game completion = session();
            Player buyer = balance(cautious ? new CautiousBot("C") : new AggressiveBot("A"), 120);
            give(completion, 1, buyer); give(completion, 2, buyer);
            completion.resolveOwnable(buyer, completion.getBoard().getOwnable(4));
            verify("last unowned property completes group at normal price / cautious=" + cautious,
                    buyer.getCash() == 0 && completion.getBoard().countOwned(buyer, ColorGroup.BROWN) == 3);
            Game railroad = session();
            Player stationBuyer = balance(cautious ? new CautiousBot("C") : new AggressiveBot("A"), 300);
            give(railroad, 7, stationBuyer);
            railroad.getBoard().getSquare(17).land(stationBuyer, railroad);
            verify("last station uses normal $300 price / cautious=" + cautious,
                    stationBuyer.getCash() == 0 && railroad.getBoard().countOwned(stationBuyer, ColorGroup.RAILROAD) == 2);
        }
        Game cannotComplete = session(); Player poor = balance(new CautiousBot("Poor"), 119);
        give(cannotComplete, 1, poor); give(cannotComplete, 2, poor);
        cannotComplete.resolveOwnable(poor, cannotComplete.getBoard().getOwnable(4));
        verify("group completion still requires funds", cannotComplete.getBoard().getOwnable(4).getOwner() == null);
        Game ordinary = session(); Player reserve = balance(new CautiousBot("Reserve"), 120);
        ordinary.resolveOwnable(reserve, ordinary.getBoard().getOwnable(1));
        verify("earlier group purchase does not bypass cautious reserve", reserve.getCash() == 120
                && ordinary.getBoard().getOwnable(1).getOwner() == null);
    }

    private static void rentAndBuyoutChecks() throws Exception {
        Game base = session(); Player owner = new AggressiveBot("Owner"), guest = new CautiousBot("Guest");
        give(base, 2, owner);
        base.resolveOwnable(guest, base.getBoard().getOwnable(2));
        verify("base property rent goes to owner", owner.getCash() == 848 && guest.getCash() == 752);
        give(base, 1, owner); give(base, 4, owner);
        base.resolveOwnable(guest, base.getBoard().getOwnable(2));
        verify("complete group doubles property rent", owner.getCash() == 944 && guest.getCash() == 656);
        Game stations = session(); Player holder = new AggressiveBot("Holder"), rider = new AggressiveBot("Rider");
        give(stations, 7, holder);
        stations.getBoard().getSquare(7).land(rider, stations);
        verify("one station charges $100", rider.getCash() == 700 && holder.getCash() == 900);
        give(stations, 17, holder);
        stations.getBoard().getSquare(7).land(rider, stations);
        verify("two stations charge $200", rider.getCash() == 500 && holder.getCash() == 1100);
        for (boolean cautious : new boolean[] {true, false}) {
            Game game = session();
            Player buyer = balance(cautious ? new CautiousBot("Buyer") : new AggressiveBot("Buyer"), 180);
            Player seller = new AggressiveBot("Seller");
            give(game, 1, buyer); give(game, 2, buyer); give(game, 4, seller);
            game.resolveOwnable(buyer, game.getBoard().getOwnable(4));
            verify("$180 buy-out replaces rent / cautious=" + cautious, buyer.getCash() == 0
                    && seller.getCash() == 980 && game.getBoard().getOwnable(4).getOwner() == buyer);
            verify("buy-out updates BOTH lists / cautious=" + cautious,
                    buyer.getProperties().size() == 3 && seller.getProperties().isEmpty());
            verify("net worth uses original prices / cautious=" + cautious, buyer.getNetWorth() == 320);
            Game rail = session();
            Player railBuyer = balance(cautious ? new CautiousBot("Buyer") : new AggressiveBot("Buyer"), 450);
            Player railSeller = new AggressiveBot("Seller");
            give(rail, 7, railBuyer); give(rail, 17, railSeller);
            rail.resolveOwnable(railBuyer, rail.getBoard().getOwnable(17));
            verify("station buy-out costs $450 / cautious=" + cautious, railBuyer.getCash() == 0
                    && railSeller.getCash() == 1250 && railSeller.getProperties().isEmpty());
        }
        Game insufficient = session(); Player near = balance(new CautiousBot("Near"), 179);
        Player seller = new AggressiveBot("Seller");
        give(insufficient, 1, near); give(insufficient, 2, near); give(insufficient, 4, seller);
        insufficient.resolveOwnable(near, insufficient.getBoard().getOwnable(4));
        verify("unaffordable buy-out falls back to rent", near.getCash() == 123
                && seller.getCash() == 856 && insufficient.getBoard().getOwnable(4).getOwner() == seller);
        Game noSet = session(); Player wealthy = new AggressiveBot("Wealthy"), original = new AggressiveBot("Original");
        give(noSet, 4, original);
        noSet.resolveOwnable(wealthy, noSet.getBoard().getOwnable(4));
        verify("cash alone cannot trigger buy-out", wealthy.getCash() == 744
                && noSet.getBoard().getOwnable(4).getOwner() == original);
        Player broke = balance(new CautiousBot("Broke"), 1);
        noSet.resolveOwnable(broke, noSet.getBoard().getOwnable(4));
        verify("Phase 2 rent can make cash negative", broke.getCash() == -55);
        try {
            noSet.transferOwnership(noSet.getBoard().getOwnable(4), wealthy, broke, 0);
            throw new AssertionError("Stale seller allowed");
        } catch (IllegalArgumentException expected) {
            verify("invalid seller rejected without mutation", noSet.getBoard().getOwnable(4).getOwner() == original
                    && broke.getCash() == -55);
        }
    }

    private static void movementAndRankingChecks() throws Exception {
        Random expected = new Random(1234); Dice dice = new Dice(1234); boolean consistent = true;
        for (int roll = 0; roll < 1000; roll++) {
            int[] pair = dice.roll();
            consistent &= pair.length == 2 && pair[0] == expected.nextInt(6) + 1 && pair[1] == expected.nextInt(6) + 1;
        }
        verify("1000 dice pairs match one Random", consistent);
        for (int[] movement : new int[][] {{13, 7, 0, 900}, {18, 7, 5, 900}, {0, 7, 7, 800}}) {
            Game game = session(); Player player = new AggressiveBot("Walker"); player.setPosition(movement[0]);
            game.movePlayer(player, movement[1]);
            verify("forward move / GO salary from " + movement[0], player.getPosition() == movement[2] && player.getCash() == movement[3]);
        }
        Game dispatch = session(); Player roller = new AggressiveBot("Roller");
        dispatch.takeTurn(roller);
        verify("turn invokes destination land method", roller.getPosition() == 7
                && dispatch.getBoard().getOwnable(7).getOwner() == roller && roller.getCash() == 500);
        Game special = session(); Player visitor = new AggressiveBot("Visitor");
        String text = record(() -> {
            for (int index : new int[] {0, 3, 5, 10, 13, 15}) { special.getBoard().getSquare(index).land(visitor, special); }
        });
        verify("specials print messages without future effects", text.contains("just visiting")
                && times(text, "Phase 3") == 3 && visitor.getCash() == 800
                && visitor.getPosition() == 0 && visitor.getJailTurns() == 0);
        Player high = balance(new AggressiveBot("Z"), 801);
        Player a = new AggressiveBot("A"), b = new AggressiveBot("B"), invested = balance(new AggressiveBot("C"), 700);
        Game values = session(); give(values, 1, invested);
        ArrayList<Player> ranking = new ArrayList<>(Arrays.asList(invested, b, high, a));
        Collections.sort(ranking);
        verify("comparison uses worth then cash then name", ranking.equals(Arrays.asList(high, a, b, invested)));
    }

    private static void inputAndRoundChecks() throws Exception {
        Game first = session(), second = session();
        String one = record(() -> { start(first, setup("42")); first.play(); });
        String two = record(() -> { start(second, setup("42")); second.play(); });
        verify("same seed and input reproduce complete game", one.equals(two));
        verify("20 rounds and one turn per player per round", times(one, "=== ROUND ") == 20
                && times(one, " rolls ") == 20 * Game.NUM_PLAYERS && first.getRound() == 20);
        verify("leaderboard after each round", times(one, "--- STANDINGS AFTER ROUND ") == 20);
        boolean retained = true;
        for (int seat = 1; seat <= Game.NUM_PLAYERS; seat++) {
            retained &= first.getPlayers().get(seat - 1).getName().equals("Seat" + seat);
        }
        verify("sorting preserves creation order", retained);
        first.getPlayers().clear();
        verify("player collection is protected", first.getPlayers().size() == Game.NUM_PLAYERS);
        Game invalid = session();
        StringBuilder bad = new StringBuilder("abc\n9999999999999999999999\n42\n\nFirst\nwrong\na\n");
        for (int seat = 2; seat <= Game.NUM_PLAYERS; seat++) { bad.append("Other").append(seat).append("\nc\n"); }
        String recovery = record(() -> start(invalid, bad.toString()));
        verify("invalid seeds retry safely", times(recovery, "Seed not accepted") == 2);
        verify("blank names and unknown types retry safely", recovery.contains("supply a name")
                && recovery.contains("Unknown strategy") && invalid.getPlayers().size() == Game.NUM_PLAYERS);
        Game random = session(); record(() -> start(random, setup("")));
        verify("empty seed supports random game", random.getPlayers().size() == Game.NUM_PLAYERS);
        Game eof = session(); String closed = record(() -> {
            if (eof.startup(new Scanner("42\nName\n"))) { throw new AssertionError("EOF accepted"); }
        });
        verify("EOF exits instead of looping or crashing", closed.contains("Input closed"));
        Game negative = session(); Player debtor = balance(new AggressiveBot("Debtor"), -100000);
        negative.addPlayer(debtor);
        String negativeGame = record(negative::play);
        verify("Phase 2 does not eliminate negative-cash players", times(negativeGame, "Debtor rolls ") == 20
                && negative.getPlayers().contains(debtor));
    }

    private static void customMoneyChecks() throws Exception {
        String original = new String(Files.readAllBytes(Paths.get("board.txt")), StandardCharsets.UTF_8);
        String odd = original.replace("4,PROPERTY,Al-Oud,BROWN,120,56", "4,PROPERTY,Al-Oud,BROWN,121,56")
                .replace("17,STATION,Grand Terminal,RAILROAD,300,100", "17,STATION,Grand Terminal,RAILROAD,301,100");
        Path custom = Files.createTempFile("riyadhpoly-board-", ".txt");
        try {
            Files.write(custom, odd.getBytes(StandardCharsets.UTF_8));
            for (boolean cautious : new boolean[] {true, false}) {
                for (double funds : new double[] {181, 181.5, 182}) {
                    Game game = new Game(custom.toString(), 42);
                    Player buyer = balance(cautious ? new CautiousBot("Buyer") : new AggressiveBot("Buyer"), funds);
                    Player owner = new AggressiveBot("Owner");
                    give(game, 1, buyer); give(game, 2, buyer); give(game, 4, owner);
                    Ownable asset = game.getBoard().getOwnable(4);
                    String output = record(() -> game.resolveOwnable(buyer, asset));
                    boolean bought = funds >= 181.5;
                    verify("exact $181.50 buy-out / cash=" + funds + " / cautious=" + cautious,
                            bought ? asset.getOwner() == buyer && buyer.getCash() == funds - 181.5
                                && owner.getCash() == 981.5 && owner.getProperties().isEmpty()
                                && buyer.getNetWorth() == funds - 181.5 + 321 && output.contains("$181.50")
                            : asset.getOwner() == owner && buyer.getCash() == 125 && owner.getCash() == 856);
                }
            }
            Game rail = new Game(custom.toString(), 42); Player buyer = balance(new CautiousBot("Buyer"), 451.5);
            Player seller = new AggressiveBot("Seller"); give(rail, 7, buyer); give(rail, 17, seller);
            rail.resolveOwnable(buyer, rail.getBoard().getOwnable(17));
            verify("fractional station buy-out", buyer.getCash() == 0 && seller.getCash() == 1251.5
                    && rail.getBoard().getOwnable(17).getOwner() == buyer);
            Player next = balance(new AggressiveBot("Next"), 452);
            rail.transferOwnership(rail.getBoard().getOwnable(17), buyer, next, 45150);
            verify("fractional balances persist through later transfer", next.getCash() == 0.5 && buyer.getCash() == 451.5);
            Player low = balance(new AggressiveBot("A"), 300), high = balance(new AggressiveBot("Z"), 300.01);
            verify("comparison retains cents", high.compareTo(low) < 0);
            verify("display retains cents and negative values", Amounts.display(18150).equals("181.50")
                    && Amounts.display(-50).equals("-0.50") && Amounts.display(80000).equals("800"));
            for (double invalid : new double[] {Double.NaN, Double.POSITIVE_INFINITY, 1.001}) {
                try { high.adjustCash(invalid); throw new AssertionError("Invalid cash accepted"); }
                catch (IllegalArgumentException expected) {
                    verify("reject invalid cash adjustment " + invalid, high.getCash() == 300.01);
                }
            }
            Files.write(custom, odd.replace("121,56", "121,1500000000").getBytes(StandardCharsets.UTF_8));
            Game huge = new Game(custom.toString(), 42); Player holder = new AggressiveBot("Holder"), guest = new AggressiveBot("Guest");
            for (int index : new int[] {1, 2, 4}) { give(huge, index, holder); }
            huge.resolveOwnable(guest, huge.getBoard().getOwnable(4));
            verify("large doubled rent does not overflow", guest.getCashCents() == -299999920000L
                    && holder.getCashCents() == 300000080000L);
        } finally { Files.deleteIfExists(custom); }
    }
}
