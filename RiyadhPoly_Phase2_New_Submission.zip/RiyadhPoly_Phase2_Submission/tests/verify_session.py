"""Optional independent rules audit: python3 tests/verify_session.py (JDK + Python 3)."""
from pathlib import Path
import csv
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def execute(command, input_text="", directory=ROOT, status=0):
    result = subprocess.run(command, input=input_text, text=True, capture_output=True,
                            cwd=directory, timeout=30)
    assert result.returncode == status, result.stdout + result.stderr
    return result.stdout + result.stderr


def answers(seed, names, strategies):
    return str(seed) + "\n" + "".join(name + "\n" + kind + "\n"
                                     for name, kind in zip(names, strategies))


class SeededDice:
    # java.util.Random's specified 48-bit generator, implemented independently.
    def __init__(self, seed):
        self.state = (seed ^ 0x5DEECE66D) & ((1 << 48) - 1)

    def die(self):
        while True:
            self.state = (self.state * 0x5DEECE66D + 0xB) & ((1 << 48) - 1)
            bits = self.state >> 17
            value = bits % 6
            if bits - value + 5 < 1 << 31:
                return value + 1


def dollars(cents):
    sign = "-" if cents < 0 else ""
    whole, fraction = divmod(abs(cents), 100)
    return sign + str(whole) + (f".{fraction:02d}" if fraction else "")


def audit(output, board_path, seed, names, strategies):
    board = []
    for row in csv.reader(board_path.read_text().splitlines()):
        if row and not row[0].startswith("#"):
            _, kind, name, group, price, rent = row
            board.append((kind, name, group, int(price or 0), int(rent or 0)))
    groups = {group: [i for i, s in enumerate(board) if s[2] == group]
              for group in {s[2] for s in board if s[2]}}
    cash, position, owners = [80000] * len(names), [0] * len(names), [None] * 20
    dice = SeededDice(seed)
    rounds = re.findall(r"=== ROUND (\d+) / 20 ===\n(.*?)(?=\n=== ROUND |\nSession complete:|\Z)", output, re.S)
    assert len(rounds) == 20
    for round_index, (number, body) in enumerate(rounds, 1):
        assert int(number) == round_index
        turns, leaderboard = body.split(f"--- STANDINGS AFTER ROUND {number} ---\n")
        blocks = re.findall(r"([^\n]+) rolls (\d+) \+ (\d+) = (\d+)\.\n(.*?)(?=[^\n]+ rolls \d+ \+ |\Z)", turns, re.S)
        assert len(blocks) == len(names)
        for p, (name, first, second, total, actions) in enumerate(blocks):
            a, b = dice.die(), dice.die()
            assert (name, int(first), int(second), int(total)) == (names[p], a, b, a + b)
            previous = position[p]
            position[p] = (previous + a + b) % 20
            index = position[p]
            kind, landmark, group, price, rent = board[index]
            expected = [f"Route: {previous} -> {index} ({landmark})."]
            if position[p] < previous:
                cash[p] += 10000
                expected.append(f"GO salary: {name} receives $100.")
            if group:
                expected.append(f"Location: {landmark} / {group}.")
                owner = owners[index]
                completion = sum(owners[s] == p for s in groups[group]) == len(groups[group]) - 1
                cost = price * 100
                if owner is None:
                    expected.append(f"Bank offer: ${price}.")
                    if cash[p] >= cost and (completion or strategies[p] == "A" or cash[p] - cost >= 30000):
                        owners[index] = p
                        cash[p] -= cost
                        expected.append(f"Purchase confirmed: {name} acquires {landmark} for ${price}.")
                    else:
                        expected.append(f"Offer declined by {name}.")
                elif owner == p:
                    expected.append(f"No payment: {name} already owns this location.")
                elif completion and cash[p] >= price * 150:
                    premium = price * 150
                    cash[p] -= premium
                    cash[owner] += premium
                    owners[index] = p
                    expected.append(f"Buy-out completed: {name} pays {names[owner]} ${dollars(premium)} for {landmark}; {group} is now complete.")
                else:
                    full_group = all(owners[s] == owner for s in groups[group])
                    payment = rent * (200 if full_group else 100)
                    cash[p] -= payment
                    cash[owner] += payment
                    label = "complete group" if full_group else "base rent"
                    expected.append(f"Rent payment: {name} -> {names[owner]} | ${dollars(payment)} ({label}).")
            else:
                expected.append({
                    "GO": f"GO checkpoint: {name} reached {landmark}.",
                    "PARK": f"Park break: {name} rests at {landmark}.",
                    "JAIL": f"Jail corner: {name} is just visiting {landmark}.",
                    "CHANCE": f"Chance stop: {landmark}. Card effects begin in Phase 3.",
                    "GO_TO_JAIL": f"Go-to-jail notice: {landmark}. Movement and penalties begin in Phase 3."
                }[kind])
            assert actions.strip().splitlines() == expected, (seed, round_index, name, actions, expected)
        worth = [cash[p] + sum(board[i][3] * 100 for i in range(20) if owners[i] == p)
                 for p in range(len(names))]
        ranking = sorted(range(len(names)), key=lambda p: (-worth[p], -cash[p], names[p]))
        expected = [f"{place}. {names[p]} | cash ${dollars(cash[p])} | net worth ${dollars(worth[p])}"
                    for place, p in enumerate(ranking, 1)]
        assert leaderboard.strip().splitlines() == expected, (seed, round_index, leaderboard, expected)
    assert "Session complete: 20 rounds played." in output


names = ["Samira", "Nabil", "Dalia", "Omar"]
jar = ["java", "-jar", "RiyadhPoly.jar"]
strategies = ["A", "C", "C", "A"]
first = execute(jar, answers(42, names, strategies))
assert first == execute(jar, answers(42, names, strategies))
audit(first, ROOT / "board.txt", 42, names, strategies)
print("OK: packaged JAR repeats exactly for seed 42, including all 80 turns and 20 standings")
invalid = execute(jar, "mistake\n9999999999999999999999\n42\n\nSamira\n?\na\nNabil\nc\nDalia\nc\nOmar\na\n")
assert invalid.count("Seed not accepted") == 2 and "Unknown strategy" in invalid and "supply a name" in invalid
audit(invalid, ROOT / "board.txt", 42, names, strategies)
print("OK: malformed seed, numeric overflow, blank name and bad bot type recover into a valid full game")
assert "Input closed" in execute(jar, "42\nOnlyName\n")
for bad_board in sorted((ROOT / "invalid_board_exceptions").glob("*.txt")):
    assert "Unable to prepare board" in execute(jar + [str(bad_board)], status=1)
print("OK: EOF and all three invalid board fixtures handled correctly")
locale = execute(["java", "-Duser.language=de", "-Duser.country=DE", "-jar", "RiyadhPoly.jar"], answers(42, names, strategies))
assert locale == first
print("OK: fixed-seed output and money formatting do not depend on display locale")

# Recompile a private copy; NUM_PLAYERS is the ONLY source change.
with tempfile.TemporaryDirectory(prefix="riyadhpoly-seats-") as directory:
    variant = Path(directory)
    shutil.copytree(ROOT / "src", variant / "src")
    shutil.copy(ROOT / "board.txt", variant / "board.txt")
    game = variant / "src/Game.java"
    source = game.read_text()
    assert source.count("NUM_PLAYERS = 4;") == 1
    game.write_text(source.replace("NUM_PLAYERS = 4;", "NUM_PLAYERS = 2;"))
    (variant / "out").mkdir()
    compiler = ["javac"] if shutil.which("javac") else ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
    execute(compiler + ["-source", "8", "-target", "8", "-Xlint:-options", "-encoding", "UTF-8", "-d", "out"]
            + [str(p) for p in sorted((variant / "src").glob("*.java"))], directory=variant)
    output = execute(["java", "-cp", "out", "RiyadhPolyApp"], answers(42, names[:2], strategies[:2]), variant)
    audit(output, variant / "board.txt", 42, names[:2], strategies[:2])
print("OK: changing only NUM_PLAYERS to 2 produces 20 valid rounds and 40 turns")

# Compare every message and monetary result with an independent integer-cents model.
with tempfile.TemporaryDirectory(prefix="riyadhpoly-prices-") as directory:
    custom = Path(directory) / "board.txt"
    rows = []
    for row in csv.reader((ROOT / "board.txt").read_text().splitlines()):
        if row and not row[0].startswith("#") and row[1] in ("PROPERTY", "STATION"):
            row[4] = str(int(row[4]) + 1)
        rows.append(",".join(row))
    custom.write_text("\n".join(rows) + "\n")
    games = 0
    for board in [ROOT / "board.txt", custom]:
        for seed in [0, 25, 30, 42]:
            for mask in range(16):
                kinds = ["A" if mask & (1 << seat) else "C" for seat in range(4)]
                result = execute(jar + [str(board)], answers(seed, names, kinds))
                audit(result, board, seed, names, kinds)
                games += 1
print(f"OK: independent rules model verified {games} full games / {games * 80} turns, all 16 bot combinations, normal and odd-price boards")
print("SUCCESS: all 6 end-to-end audit groups completed.")
