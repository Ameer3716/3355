import java.util.ArrayList;

/** A player keeps shared state; each bot supplies only its buying preference. */
public abstract class Player implements Comparable<Player> {
    private final String name;
    private long cashCents = Amounts.wholeDollars(Game.INITIAL_CASH);
    private int position;
    private int turnsInJail;
    private final ArrayList<Ownable> properties = new ArrayList<>();

    protected Player(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("A player needs a name.");
        }
        this.name = name.trim();
    }

    public final String getName() { return name; }
    public final double getCash() { return Amounts.toDollars(cashCents); }
    public final long getCashCents() { return cashCents; }
    public final int getPosition() { return position; }
    public final int getJailTurns() { return turnsInJail; }

    public final void setPosition(int destination) {
        if (destination < 0 || destination >= Board.BOARD_SIZE) {
            throw new IllegalArgumentException("Destination must be on the board.");
        }
        position = destination;
    }

    public final void setJailTurns(int turns) {
        if (turns < 0) { throw new IllegalArgumentException("Jail turns cannot be negative."); }
        turnsInJail = turns;
    }

    public final void adjustCash(double dollars) {
        adjustCashCents(Amounts.toCents(dollars));
    }

    final void adjustCashCents(long change) {
        cashCents = Math.addExact(cashCents, change);
    }

    final void addProperty(Ownable asset) {
        if (!properties.contains(asset)) { properties.add(asset); }
    }

    final void removeProperty(Ownable asset) { properties.remove(asset); }

    public final ArrayList<Ownable> getProperties() {
        return new ArrayList<>(properties);
    }

    public final long getNetWorthCents() {
        long total = cashCents;
        for (Ownable asset : properties) {
            total = Math.addExact(total, Amounts.wholeDollars(asset.getPrice()));
        }
        return total;
    }

    public final double getNetWorth() { return Amounts.toDollars(getNetWorthCents()); }

    public abstract boolean wantsToBuy(Ownable asset);

    @Override
    public final int compareTo(Player other) {
        int order = Long.compare(other.getNetWorthCents(), getNetWorthCents());
        if (order != 0) { return order; }
        order = Long.compare(other.cashCents, cashCents);
        return order != 0 ? order : name.compareTo(other.name);
    }
}
