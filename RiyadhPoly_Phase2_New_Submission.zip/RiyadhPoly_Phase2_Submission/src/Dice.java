import java.util.Random;

public class Dice {
    public static final int DICE_COUNT = 2;
    public static final int SIDES = 6;
    private final Random random;

    public Dice(Random random) {
        if (random == null) { throw new IllegalArgumentException("Dice need a generator."); }
        this.random = random;
    }

    public Dice(long seed) { this(new Random(seed)); }

    public int[] roll() {
        int[] values = new int[DICE_COUNT];
        for (int die = 0; die < values.length; die++) {
            values[die] = random.nextInt(SIDES) + 1;
        }
        return values;
    }
}
