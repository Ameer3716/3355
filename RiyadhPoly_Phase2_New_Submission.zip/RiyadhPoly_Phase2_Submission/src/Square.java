public abstract class Square {
    private final int index;
    private final String name;

    protected Square(int index, String name) {
        this.index = index;
        this.name = name;
    }

    public final int getIndex() { return index; }
    public final String getName() { return name; }

    @Override
    public String toString() {
        return String.format("%02d | %s", index, name);
    }

    public abstract void land(Player p, Game g);
}
