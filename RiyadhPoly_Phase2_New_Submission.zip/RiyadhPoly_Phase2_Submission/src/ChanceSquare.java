public class ChanceSquare extends Square {
    public ChanceSquare(int index, String name) {
        super(index, name);
    }

    @Override
    public void land(Player p, Game g) {
        System.out.println("Chance stop: " + getName() + ". Card effects begin in Phase 3.");
    }
}
