import java.math.BigDecimal;

/** Exact cash storage in cents; board prices remain whole-dollar integers. */
public final class Amounts {
    public static final int CENTS_PER_DOLLAR = 100;

    private Amounts() { }

    public static long wholeDollars(int dollars) {
        return (long) dollars * CENTS_PER_DOLLAR;
    }

    public static long toCents(double dollars) {
        try {
            return BigDecimal.valueOf(dollars).movePointRight(2).longValueExact();
        } catch (NumberFormatException | ArithmeticException invalid) {
            throw new IllegalArgumentException("Cash must be a finite amount with at most two decimals.", invalid);
        }
    }

    public static double toDollars(long cents) {
        return cents / (double) CENTS_PER_DOLLAR;
    }

    public static String display(long cents) {
        return cents % CENTS_PER_DOLLAR == 0
                ? Long.toString(cents / CENTS_PER_DOLLAR)
                : BigDecimal.valueOf(cents, 2).toPlainString();
    }
}
