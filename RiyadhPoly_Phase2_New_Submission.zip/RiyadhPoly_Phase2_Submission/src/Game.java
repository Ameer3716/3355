import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class Game {
    public static final int NUM_PLAYERS = 4;
    public static final int INITIAL_CASH = 800;
    public static final int SALARY = 100;
    public static final int MAX_ROUNDS = 20;
    public static final double BUYOUT_FACTOR = 1.5;
    public static final int FULL_GROUP_RENT_MULTIPLIER = 2;

    private final Board board;
    private final ArrayList<Player> players = new ArrayList<>();
    private Dice dice;
    private int round;

    public Game(String fileName) throws InvalidBoardException {
        board = new Board(fileName);
    }

    public Game(String fileName, long seed) throws InvalidBoardException {
        this(fileName);
        dice = new Dice(seed);
    }

    public Board getBoard() { return board; }
    public int getRound() { return round; }
    public ArrayList<Player> getPlayers() { return new ArrayList<>(players); }

    public void addPlayer(Player player) {
        if (player == null || players.contains(player)) {
            throw new IllegalArgumentException("Choose a new player object.");
        }
        players.add(player);
    }

    /** All input uses complete lines, so a mistyped number cannot leave bad tokens behind. */
    public boolean startup(Scanner keyboard) {
        System.out.println("=== RIYADHPOLY / PLAYERS AND MONEY ===");
        System.out.println("Board ready: " + board.getSquares().size() + " locations.");
        while (true) {
            String seedText = readAnswer(keyboard, "Seed number [Enter = random]: ");
            if (seedText == null) { return false; }
            try {
                Random generator = seedText.isEmpty() ? new Random() : new Random(Long.parseLong(seedText));
                dice = new Dice(generator);
                break;
            } catch (NumberFormatException invalid) {
                System.out.println("Seed not accepted. Use a whole number or leave it blank.");
            }
        }
        players.clear();
        for (int seat = 1; seat <= NUM_PLAYERS; seat++) {
            String name;
            do {
                name = readAnswer(keyboard, "Seat " + seat + " - player name: ");
                if (name == null) { return false; }
                if (name.isEmpty()) { System.out.println("Please supply a name for this seat."); }
            } while (name.isEmpty());
            while (true) {
                String strategy = readAnswer(keyboard, "Strategy for " + name + " [C cautious / A aggressive]: ");
                if (strategy == null) { return false; }
                if (strategy.equalsIgnoreCase("C")) { addPlayer(new CautiousBot(name)); break; }
                if (strategy.equalsIgnoreCase("A")) { addPlayer(new AggressiveBot(name)); break; }
                System.out.println("Unknown strategy. Enter C or A.");
            }
        }
        ArrayList<String> order = new ArrayList<>();
        for (Player player : players) { order.add(player.getName()); }
        System.out.println("Turn sequence: " + String.join(" -> ", order));
        return true;
    }

    private String readAnswer(Scanner keyboard, String prompt) {
        System.out.print(prompt);
        if (!keyboard.hasNextLine()) {
            System.out.println("\nInput closed; no game started.");
            return null;
        }
        return keyboard.nextLine().trim();
    }

    public void play() {
        if (dice == null || players.isEmpty()) {
            throw new IllegalStateException("Set up dice and players before starting.");
        }
        for (round = 1; round <= MAX_ROUNDS; round++) {
            System.out.println("\n=== ROUND " + round + " / " + MAX_ROUNDS + " ===");
            for (Player player : players) { takeTurn(player); }
            printLeaderboard();
        }
        round = MAX_ROUNDS;
        System.out.println("\nSession complete: " + MAX_ROUNDS + " rounds played.");
    }

    public void takeTurn(Player player) {
        if (dice == null) { throw new IllegalStateException("Dice have not been prepared."); }
        int[] values = dice.roll();
        int steps = values[0] + values[1];
        System.out.println(player.getName() + " rolls " + values[0] + " + " + values[1] + " = " + steps + ".");
        movePlayer(player, steps);
        board.getSquare(player.getPosition()).land(player, this);
    }

    public void movePlayer(Player player, int steps) {
        // The Phase 2 dice move forward by 2..12, so at most one GO crossing is possible.
        if (steps < 0 || steps >= Board.BOARD_SIZE) {
            throw new IllegalArgumentException("A Phase 2 move must be forward and shorter than the board.");
        }
        int departure = player.getPosition();
        int destination = (departure + steps) % Board.BOARD_SIZE;
        player.setPosition(destination);
        System.out.println("Route: " + departure + " -> " + destination + " ("
                + board.getSquare(destination).getName() + ").");
        if (destination < departure) {
            player.adjustCash(SALARY);
            System.out.println("GO salary: " + player.getName() + " receives $" + SALARY + ".");
        }
    }

    /** Bank purchases and player buy-outs both change ownership ONLY here. */
    public void transferOwnership(Ownable asset, Player seller, Player buyer, long paymentCents) {
        if (asset == null || !board.getSquares().contains(asset) || buyer == null || buyer == seller
                || asset.getOwner() != seller || paymentCents < 0 || buyer.getCashCents() < paymentCents) {
            throw new IllegalArgumentException("Ownership transfer cannot be completed.");
        }
        buyer.adjustCashCents(-paymentCents);
        if (seller != null) {
            seller.adjustCashCents(paymentCents);
            seller.removeProperty(asset);
        }
        buyer.addProperty(asset);
        asset.setOwner(buyer);
    }

    public void resolveOwnable(Player visitor, Ownable asset) {
        System.out.println("Location: " + asset.getName() + " / " + asset.getGroup() + ".");
        if (asset.getOwner() == null) {
            offerBankPurchase(visitor, asset);
        } else if (asset.getOwner() == visitor) {
            System.out.println("No payment: " + visitor.getName() + " already owns this location.");
        } else {
            settleVisit(visitor, asset);
        }
    }

    private boolean finishesGroup(Player player, Ownable asset) {
        String group = asset.getGroup();
        return board.countOwned(player, group) == board.getGroupSize(group) - 1;
    }

    private void offerBankPurchase(Player buyer, Ownable asset) {
        long cost = Amounts.wholeDollars(asset.getPrice());
        System.out.println("Bank offer: $" + Amounts.display(cost) + ".");
        if (buyer.getCashCents() >= cost && (finishesGroup(buyer, asset) || buyer.wantsToBuy(asset))) {
            transferOwnership(asset, null, buyer, cost);
            System.out.println("Purchase confirmed: " + buyer.getName() + " acquires "
                    + asset.getName() + " for $" + Amounts.display(cost) + ".");
        } else {
            System.out.println("Offer declined by " + buyer.getName() + ".");
        }
    }

    private void settleVisit(Player visitor, Ownable asset) {
        Player holder = asset.getOwner();
        long premium = Amounts.toCents(asset.getPrice() * BUYOUT_FACTOR);
        if (finishesGroup(visitor, asset) && visitor.getCashCents() >= premium) {
            transferOwnership(asset, holder, visitor, premium);
            System.out.println("Buy-out completed: " + visitor.getName() + " pays " + holder.getName()
                    + " $" + Amounts.display(premium) + " for " + asset.getName()
                    + "; " + asset.getGroup() + " is now complete.");
            return;
        }
        boolean completeSet = board.countOwned(holder, asset.getGroup()) == board.getGroupSize(asset.getGroup());
        long rent = Amounts.wholeDollars(asset.getBaseRent());
        if (completeSet) { rent *= FULL_GROUP_RENT_MULTIPLIER; }
        visitor.adjustCashCents(-rent);
        holder.adjustCashCents(rent);
        System.out.println("Rent payment: " + visitor.getName() + " -> " + holder.getName()
                + " | $" + Amounts.display(rent) + (completeSet ? " (complete group)." : " (base rent)."));
    }

    public void printLeaderboard() {
        ArrayList<Player> ranking = new ArrayList<>(players);
        Collections.sort(ranking);
        System.out.println("--- STANDINGS AFTER ROUND " + round + " ---");
        for (int place = 0; place < ranking.size(); place++) {
            Player player = ranking.get(place);
            System.out.println((place + 1) + ". " + player.getName() + " | cash $"
                    + Amounts.display(player.getCashCents()) + " | net worth $"
                    + Amounts.display(player.getNetWorthCents()));
        }
    }
}
