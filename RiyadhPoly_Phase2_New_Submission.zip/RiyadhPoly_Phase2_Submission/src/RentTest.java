/** Standalone Phase 2 demonstration with checks that do not depend on -ea. */
public class RentTest {
    public static void main(String[] args) throws InvalidBoardException {
        Game demonstration = new Game("board.txt", 42);
        Player rana = new AggressiveBot("Rana");
        Player yousef = new CautiousBot("Yousef");
        Ownable first = demonstration.getBoard().getOwnable(1);
        Ownable second = demonstration.getBoard().getOwnable(2);
        Ownable last = demonstration.getBoard().getOwnable(4);
        demonstration.transferOwnership(first, null, rana, Amounts.wholeDollars(100));
        demonstration.transferOwnership(second, null, rana, Amounts.wholeDollars(100));
        demonstration.transferOwnership(last, null, yousef, Amounts.wholeDollars(120));
        demonstration.resolveOwnable(rana, last);
        require(last.getOwner() == rana, "Buy-out did not change the square owner.");
        require(rana.getCashCents() == 42000 && yousef.getCashCents() == 86000,
                "The buy-out must pay $180 to the seller, with no additional rent.");
        require(rana.getProperties().size() == 3 && yousef.getProperties().isEmpty(),
                "Both ownership lists must be updated.");
        demonstration.resolveOwnable(yousef, second);
        require(rana.getCashCents() == 51600 && yousef.getCashCents() == 76400,
                "The complete BROWN group must charge $96 on Al-Bathaa.");
        System.out.println("Al-Oud holder: " + last.getOwner().getName());
        System.out.println("Yousef cash after rent: $" + Amounts.display(yousef.getCashCents()));
        System.out.println("RentTest successful: buy-out $180; doubled rent $96; balances Rana $516 / Yousef $764.");
    }

    private static void require(boolean result, String message) {
        if (!result) { throw new AssertionError(message); }
    }
}
