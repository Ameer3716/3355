public class GoToJailSquare extends Square {
    public GoToJailSquare(int index, String name) {
        super(index, name);
    }

    @Override
    public void land(Player p, Game g) {
        System.out.println("Go-to-jail notice: " + getName() + ". Movement and penalties begin in Phase 3.");
    }
}
