public class AggressiveBot extends Player {
    public AggressiveBot(String name) { super(name); }

    @Override
    public boolean wantsToBuy(Ownable asset) {
        return getCashCents() >= Amounts.wholeDollars(asset.getPrice());
    }
}
