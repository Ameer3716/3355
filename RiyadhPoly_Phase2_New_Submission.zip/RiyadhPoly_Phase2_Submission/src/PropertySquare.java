public class PropertySquare extends Square implements Ownable {
    private final String group;
    private final int price;
    private final int baseRent;
    private Player owner;

    public PropertySquare(int index, String name, String group, int price, int baseRent) {
        super(index, name);
        this.group = group;
        this.price = price;
        this.baseRent = baseRent;
    }

    @Override public int getPrice() { return price; }
    @Override public int getBaseRent() { return baseRent; }
    @Override public String getGroup() { return group; }
    @Override public Player getOwner() { return owner; }
    @Override public void setOwner(Player player) { owner = player; }

    @Override
    public void land(Player player, Game game) {
        game.resolveOwnable(player, this);
    }

    @Override
    public String toString() {
        return super.toString() + " | property | " + group
                + " | price=$" + price + " | rent=$" + baseRent;
    }
}
