import java.util.Scanner;

public class RiyadhPolyApp {
    public static void main(String[] args) {
        String source = args.length == 0 ? "board.txt" : args[0];
        try (Scanner keyboard = new Scanner(System.in)) {
            Game session = new Game(source);
            if (session.startup(keyboard)) { session.play(); }
        } catch (InvalidBoardException problem) {
            System.err.println("Unable to prepare board [" + source + "]: " + problem.getMessage());
            System.exit(1);
        }
    }
}
