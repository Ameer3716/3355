public class CautiousBot extends Player {
    public static final int BOT_RESERVE = 300;

    public CautiousBot(String name) { super(name); }

    @Override
    public boolean wantsToBuy(Ownable asset) {
        long remaining = getCashCents() - Amounts.wholeDollars(asset.getPrice());
        return remaining >= Amounts.wholeDollars(BOT_RESERVE);
    }
}
