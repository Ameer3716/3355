import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Board {
    public static final int BOARD_SIZE = 20;
    public static final int CSV_FIELD_COUNT = 6;
    private static final int INDEX_COLUMN = 0;
    private static final int TYPE_COLUMN = 1;
    private static final int NAME_COLUMN = 2;
    private static final int GROUP_COLUMN = 3;
    private static final int PRICE_COLUMN = 4;
    private static final int RENT_COLUMN = 5;

    private final ArrayList<Square> locations = new ArrayList<>();
    private final Map<String, ArrayList<Ownable>> ownershipGroups = new LinkedHashMap<>();

    public Board(String fileName) throws InvalidBoardException {
        loadBoard(fileName);
    }

    public ArrayList<Square> getSquares() {
        return new ArrayList<>(locations);
    }

    public Square getSquare(int index) {
        return locations.get(index);
    }

    public Ownable getOwnable(int index) {
        Square square = getSquare(index);
        if (!(square instanceof Ownable)) {
            throw new IllegalArgumentException("Location " + index + " is not for sale.");
        }
        return (Ownable) square;
    }

    public int getGroupSize(String group) {
        List<Ownable> assets = ownershipGroups.get(group);
        return assets == null ? 0 : assets.size();
    }

    public int countOwned(Player player, String group) {
        if (player == null) {
            return 0;
        }
        List<Ownable> assets = ownershipGroups.get(group);
        if (assets == null) {
            return 0;
        }
        int count = 0;
        for (Ownable asset : assets) {
            if (asset.getOwner() == player) {
                count++;
            }
        }
        return count;
    }

    public void printBoard() {
        for (Square square : locations) {
            System.out.println(square);
        }
    }

    private void loadBoard(String fileName) throws InvalidBoardException {
        final List<String> lines;
        try {
            lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
        } catch (IOException | InvalidPathException error) {
            InvalidBoardException invalid = new InvalidBoardException(
                    "cannot read board file: " + error.getMessage());
            invalid.initCause(error);
            throw invalid;
        }
        for (int offset = 0; offset < lines.size(); offset++) {
            String line = lines.get(offset);
            if (offset == 0 && line.startsWith("\uFEFF")) {
                line = line.substring(1);
            }
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            int lineNumber = offset + 1;
            if (locations.size() >= BOARD_SIZE) {
                throw new InvalidBoardException(lineNumber,
                        "too many squares; expected " + BOARD_SIZE);
            }
            Square square = parseSquare(line, lineNumber, locations.size());
            locations.add(square);
            registerOwnable(square);
        }
        if (locations.size() != BOARD_SIZE) {
            throw new InvalidBoardException(
                    "expected " + BOARD_SIZE + " squares but found " + locations.size());
        }
    }

    private Square parseSquare(String line, int lineNumber, int expectedIndex)
            throws InvalidBoardException {
        String[] values = line.split(",", -1);
        if (values.length != CSV_FIELD_COUNT) {
            throw new InvalidBoardException(lineNumber,
                    "expected " + CSV_FIELD_COUNT + " fields but found " + values.length);
        }
        for (int column = 0; column < values.length; column++) {
            values[column] = values[column].trim();
        }
        int index = parseNumber(values[INDEX_COLUMN], "index", lineNumber);
        if (index != expectedIndex) {
            throw new InvalidBoardException(lineNumber,
                    "expected square index " + expectedIndex + " but found " + index);
        }
        String name = values[NAME_COLUMN];
        if (name.isEmpty()) {
            throw new InvalidBoardException(lineNumber, "square name is empty");
        }
        String type = values[TYPE_COLUMN];
        switch (type) {
            case "PROPERTY":
            case "STATION":
                return createOwnableSquare(values, index, lineNumber,
                        "STATION".equals(type));
            case "GO":
            case "CHANCE":
            case "PARK":
            case "JAIL":
            case "GO_TO_JAIL":
                checkBlankPricing(values, lineNumber);
                return createSpecialSquare(type, index, name);
            default:
                throw new InvalidBoardException(lineNumber,
                        "unknown type \"" + type + "\"");
        }
    }

    private Square createOwnableSquare(String[] values, int index, int lineNumber,
                                      boolean station) throws InvalidBoardException {
        String group = values[GROUP_COLUMN];
        if (!ColorGroup.isValid(group)) {
            throw new InvalidBoardException(lineNumber,
                    "unknown group \"" + group + "\"");
        }
        if (station != ColorGroup.RAILROAD.equals(group)) {
            throw new InvalidBoardException(lineNumber, station
                    ? "station must belong to RAILROAD"
                    : "property must belong to BROWN, YELLOW, GREEN or BLUE");
        }
        int price = parseNumber(values[PRICE_COLUMN], "price", lineNumber);
        int rent = parseNumber(values[RENT_COLUMN], "rent", lineNumber);
        if (price < 0 || rent < 0) {
            throw new InvalidBoardException(lineNumber,
                    "price and rent must not be negative");
        }
        return station
                ? new StationSquare(index, values[NAME_COLUMN], group, price, rent)
                : new PropertySquare(index, values[NAME_COLUMN], group, price, rent);
    }

    private void checkBlankPricing(String[] values, int lineNumber)
            throws InvalidBoardException {
        for (int column = GROUP_COLUMN; column <= RENT_COLUMN; column++) {
            if (!values[column].isEmpty()) {
                throw new InvalidBoardException(lineNumber,
                        "special square must leave group, price and rent empty");
            }
        }
    }

    private Square createSpecialSquare(String type, int index, String name) {
        switch (type) {
            case "GO": return new GoSquare(index, name);
            case "CHANCE": return new ChanceSquare(index, name);
            case "PARK": return new ParkSquare(index, name);
            case "JAIL": return new JailSquare(index, name);
            case "GO_TO_JAIL": return new GoToJailSquare(index, name);
            default: throw new IllegalArgumentException("unsupported special square");
        }
    }

    private int parseNumber(String text, String field, int lineNumber)
            throws InvalidBoardException {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException error) {
            InvalidBoardException invalid = new InvalidBoardException(lineNumber,
                    field + " \"" + text + "\" is not a valid integer");
            invalid.initCause(error);
            throw invalid;
        }
    }

    private void registerOwnable(Square square) {
        if (square instanceof Ownable) {
            Ownable asset = (Ownable) square;
            ownershipGroups.computeIfAbsent(asset.getGroup(),
                    key -> new ArrayList<Ownable>()).add(asset);
        }
    }
}
