RIYADHPOLY - PHASE 2: PLAYERS AND MONEY

Built on the uploaded RiyadhPoly_Phase1_Submission project. The board loader,
original board, immutable square data and original validation fixtures are retained.
Phase 2 adds players, bot policies, dice, money, purchases, rent, buy-outs and rounds.
No external libraries, services or credentials are needed.

QUICK START
1. Extract the entire ZIP and open RiyadhPoly_Phase2_Submission.
2. Install Java. A JDK is needed to rebuild/test; this package was tested on Java 21.
3. Windows: double-click run.bat. Linux/macOS: sh run.sh.
   Any terminal: java -jar RiyadhPoly.jar
4. Enter a whole-number seed (42 is an example), or press Enter for random dice.
5. Enter four names and a strategy for each: C cautious, A aggressive.
   The game then runs 20 rounds automatically.

Invalid seeds, missing names and unknown strategies are re-prompted. End of input
cancels startup without crashing. Names are user-entered, not hard-coded. For a
repeatable demonstration, use tests/seed42_input.txt with redirected input:
   java -jar RiyadhPoly.jar < tests/seed42_input.txt
Use Command Prompt on Windows for the redirection example, or a Linux/macOS shell.
Another board may be passed as the first argument:
   java -jar RiyadhPoly.jar path/to/assigned-board.txt

BUILD AND TEST
Windows: build.bat; test.bat
Linux/macOS: sh build.sh; sh test.sh
Both compile the Java sources into out/ and rebuild RiyadhPoly.jar. Tests compile
into out-tests/. Compiler module fallbacks support this cloud environment if its
javac/jar launchers are absent. Java source/bytecode target 8. Execution was verified
on Java 21; Windows batch scripts and Java 8 runtime were not executed here.

Required separate demonstration (no rebuild needed with the included JAR):
   java -cp RiyadhPoly.jar RentTest
Windows may also double-click rent-test.bat. After building, the equivalent is:
   java -cp out RentTest
Expect Rana to buy Al-Oud from Yousef for $180, then collect $96 on Al-Bathaa.
Final cash: Rana $516, Yousef $764. Names differ from the brief's illustrative
names; the board data, actions and required amounts are the same. Explicit checks
fail if cash or either ownership list is wrong; Java -ea is not required.

AUTOMATED EVIDENCE
   sh test.sh (or test.bat): 70 rule checks plus RentTest
   python3 tests/verify_session.py: 6 end-to-end audit groups (optional Python 3)
The Python audit checks the actual console output against an independent model:
128 full games / 10,240 turns, all 16 bot combinations, four seeds and two boards
(normal and all-odd prices). It also checks repeatability, invalid input, malformed
boards, display-locale independence and a two-player variant. The two-player test
changes ONLY Game.NUM_PLAYERS in a temporary source copy, leaving the submission
unchanged. Detailed results and a full seed-42 game are in docs/.

RULES AND CODE
- Game.NUM_PLAYERS=4; INITIAL_CASH=800; SALARY=100; MAX_ROUNDS=20;
  BUYOUT_FACTOR=1.5. CautiousBot.BOT_RESERVE=300.
- Dice owns one Random and consumes two six-sided rolls per turn.
- Players act in creation order. Movement uses modulo Board.BOARD_SIZE and pays
  salary when crossing or landing on GO, before the destination's land method.
- Player is abstract and Comparable. Its subclasses only decide whether they
  want a normal purchase; group-completion rules belong to Game.
- PropertySquare and StationSquare both call Game.resolveOwnable.
- Every purchase and buy-out calls Game.transferOwnership. Null seller means
  bank; payment is in CENTS. It changes buyer cash, seller cash/list when present,
  buyer list and the square's owner in one place.
- Bank purchases use ordinary prices. A buy-out applies only to an opponent-owned
  square when the visitor owns all other members of that group and can afford
  1.5 times the price. Otherwise rent is paid to its owner.
- Completing an unowned group uses the normal price. Cautious reserve is waived
  for affordable completion, whether buying from bank or buying out an owner.
- Rent is loaded from the board and doubles for full groups. Stations form the
  two-member RAILROAD group ($100 base, $200 full-group on the supplied board).
- Cash is stored as long integer cents, so $121 has an exact $181.50 buy-out.
  A player with $181 pays rent instead. Formatting keeps whole-dollar examples
  unchanged and displays fractional balances with two decimals.
- Net worth uses ORIGINAL board prices, including properties acquired by buy-out.
- Each leaderboard sorts a COPY using Collections.sort: net worth descending,
  cash descending, then names ascending. The playing order is never sorted.
- Negative cash does not eliminate a player in Phase 2. All players keep their
  scheduled turns. Chance and Go To Jail print placeholders; Jail is visiting.
  Chance cards, jail penalties, bankruptcy removal and final winner are Phase 3.

DIAGRAMS
  diagram/phase2.drawio                 current, editable two-page diagram
  diagram/game_and_players.svg          current readable diagram, opens in browser
  diagram/square_hierarchy.svg          current readable square design
  diagram/game_and_players.pdf          printable current core diagram
  diagram/square_hierarchy.pdf          printable current square design
  diagram/supplied_project_plan.drawio  original uploaded plan, includes Phase 3
  diagram/phase1_original.pdf            original Phase 1 diagram for reference
The current diagram uses the actual field/method names; private helper parameter
lists are abbreviated with ... for readability. The original plan is not a claim
that future Phase 3 classes already exist.

SUBMISSION NOTES
Read docs/requirements.md and docs/code_walkthrough.md. Test against your group's
assigned board if it differs from board.txt. Required class names and behavior
remain those in the brief. No claim about similarity/plagiarism detection is made.
The separate LMS RiyadhPoly_sample_output.txt was not supplied: comparison against
that file is not claimed. The Overview excerpt was checked for applicable rules.
The AI-use log is omitted under the earlier request. The Overview requires a log
with the final submission; omitting it leaves that final-submission requirement
unmet. Group registration, LMS upload, attendance and individual explanations
must be completed by the students. This package verifies coding requirements;
it does not claim completion of those external academic obligations.
